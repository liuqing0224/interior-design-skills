# 室内设计全流程 · 15 Skills

用统一项目数据衔接需求、测量、平面、概念、空间表现、材料、灯光、定制、机电、图纸、软装、预算、校审和交付配合。

## 快速使用

```bash
python3 install.py --target ~/.codex/skills
python3 install.py --target ~/.codex/skills --check
```

安装器先检查全部同名目录，存在冲突时不写入；不会覆盖其他技能。安装后在新会话使用：

```text
使用 $interior-orchestrator 完成 <项目目录> 的室内设计。
项目类型<住宅/办公/酒店/商业>，城市<城市>，使用人数<人数>，
面积口径<口径>，预算<金额与包含范围>，资料<平面/尺寸/照片>。
先整理输入与未知项，再提出平面方案，按阶段完成图纸、清单与校审。
```

## 技能目录

| Skill | 工作 |
|---|---|
| interior-orchestrator | 总控、阶段与版本 |
| interior-brief | 需求、任务书与预算范围 |
| interior-survey | 现状、测量与开口基线 |
| interior-layout | 平面、家具和动线 |
| interior-concept | 概念、色彩和材质方向 |
| interior-visualization | 同源模型、相机与空间表现 |
| interior-finishes | 材料、铺装和收口 |
| interior-lighting | 灯位、灯具和控制 |
| interior-joinery | 柜体、木作和五金 |
| interior-mep | 设备与专业接口 |
| interior-drawings | 平立剖、图集与CAD |
| interior-ffe | 家具、软装与采购准备 |
| interior-cost | 工程量、估算与变更费用 |
| interior-review | 校审、问题与复查 |
| interior-delivery | 交底、模板和交付包 |

共享契约在 `skills/interior-orchestrator/references/project-contract.md`，各技能有独立阶段检查表。真实项目规范适用性需依据具体地区、用途和官方文本确定；本套件不内置未经核验的法定阈值。

## 已执行项目

[栖木之家](projects/DEMO-APT-096/README.md)：用户选定的96㎡住宅示范，两卧加书房、三口之家、原木浅色。完整设计资料在项目目录，包含PDF图集、6张SVG、一份可编辑DXF、三张同源渲染、Blender/GLB模型、预算工作簿和各类CSV。

输入尺寸及单价是示范设定；交付状态为设计文件与现场配合准备。未虚构实测、询价、采购、施工或现场验收。

## 数据与复算

```bash
python3 skills/interior-orchestrator/scripts/project_tools.py check projects/DEMO-APT-096/model/project.json --out /tmp/interior-check.json
python3 skills/interior-orchestrator/scripts/project_tools.py schedules projects/DEMO-APT-096/model/project.json --out projects/DEMO-APT-096/schedules
```

工程量规则在预算行的 `quantity_rule` 中；地面、顶面、柜体、部分家具计数随模型更新，墙面/机电暂估保留来源。采购量先四舍五入到四位小数，再乘单价并四舍五入到分；预备费只计一次。

绘图与文件检查：

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python skills/interior-orchestrator/scripts/export_drawings.py projects/DEMO-APT-096
.venv/bin/python tests/test_project_tools.py
blender -b -t 4 --python skills/interior-orchestrator/scripts/render_project.py -- projects/DEMO-APT-096
```

`tools/build_book.py`重建汇报与深化PDF；中文字体从`INTERIOR_PDF_FONT`指定的TrueType文件读取，macOS默认尝试Arial Unicode，PDF内嵌字体子集。`tools/build_budget.mjs [项目目录]`使用Codex工作区的 `@oai/artifact-tool` 重建预算工作簿，Node依赖按Codex运行时配置。非Codex环境可直接使用CSV、现有工作簿和标准库复算工具。没有模型服务或API Key依赖。

`python3 tools/verify_delivery.py [项目目录]`检查DXF/SVG/PDF、模型交换文件、全部预算行及最终阶段输出哈希；需要先安装`requirements.txt`中的依赖。Blender源场景实际重新打开的证据保存在项目`state/blend-check.json`，校验器同时核对该证据对应的文件哈希。

具体已执行检查见 `VALIDATION.md`；技能格式校验不替代设计行为验证，示范设计也不等同真实工程施工成果。
