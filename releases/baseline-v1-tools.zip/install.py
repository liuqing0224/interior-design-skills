#!/usr/bin/env python3
"""Install all fifteen skills without replacing any existing directory."""
import argparse
import hashlib
import shutil
from pathlib import Path

def manifest(root):
    return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--target',type=Path,default=Path.home()/'.codex/skills');p.add_argument('--check',action='store_true');a=p.parse_args()
    sources=sorted((Path(__file__).parent/'skills').glob('interior-*'));target=a.target.expanduser()
    if len(sources)!=15:raise SystemExit('Expected exactly fifteen skills')
    if a.check:
        bad=[s.name for s in sources if not (target/s.name).is_dir() or manifest(s)!=manifest(target/s.name)]
        if bad:raise SystemExit('Mismatch: '+', '.join(bad))
        print('PASS: all 15 installed skills match canonical files');return
    conflicts=[s.name for s in sources if (target/s.name).exists()]
    if conflicts:raise SystemExit('No files written; existing directories: '+', '.join(conflicts))
    target.mkdir(parents=True,exist_ok=True)
    copied=[]
    try:
        for source in sources:
            shutil.copytree(source,target/source.name,ignore=shutil.ignore_patterns('__pycache__','*.pyc'));copied.append(target/source.name)
    except Exception:
        for path in copied:shutil.rmtree(path)
        raise
    print('Installed 15 skills into '+str(target))
if __name__=='__main__':main()
