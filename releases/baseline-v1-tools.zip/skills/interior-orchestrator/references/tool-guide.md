# 项目工具

要求Python 3.10+。纯数据、算术与几何检查仅使用标准库；绘图工具另需ezdxf、reportlab、Pillow。

```bash
python skills/interior-orchestrator/scripts/project_tools.py init /path/to/project --name "项目名"
python skills/interior-orchestrator/scripts/project_tools.py check /path/to/project/model/project.json --out /path/to/check.json
python skills/interior-orchestrator/scripts/project_tools.py schedules /path/to/project/model/project.json --out /path/to/schedules
python skills/interior-orchestrator/scripts/project_tools.py record /path/to/project --skill /path/to/skills/interior-brief --outputs 01-brief.md
```

init只写新目录，已有目录拒绝覆盖。check在发现几何、引用、预算或净距问题时返回非零，并输出具体问题。schedules导出房间、材料、灯具、设备、家具与费用表，缺字段会报错，不静默跳过。

record只能用于实际完成的阶段，输出路径需位于项目内、存在且为普通文件；记录输入/技能/输出哈希。工具本身不能证明设计判断正确或批准已经发生。
