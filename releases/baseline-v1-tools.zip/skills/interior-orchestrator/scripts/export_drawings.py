#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
from drawing_lib import SHEETS,plan,svg,dxf_document

def main():
    p=argparse.ArgumentParser();p.add_argument('project',type=Path);a=p.parse_args()
    m=json.loads((a.project/'model/project.json').read_text());out=a.project/'drawings';out.mkdir(exist_ok=True)
    for code,title,kind in SHEETS:svg(plan(m,kind),out/(code+'.svg'),title)
    doc=dxf_document(m);doc.saveas(out/'interior-set.dxf')
    print('Exported 6 SVG drawings and one 1:1 mm DXF drawing set')
if __name__=='__main__':main()
