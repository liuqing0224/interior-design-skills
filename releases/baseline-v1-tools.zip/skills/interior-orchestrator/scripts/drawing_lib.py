"""Same-source 2D drawing primitives for SVG, PDF and DXF."""
from pathlib import Path
import html
import math

SHEETS=[('ID-01','家具与空间平面','furniture'),('ID-02','地材与铺装意向','finishes'),
 ('ID-03','灯位与控制分组','lighting'),('ID-04','设备与机电条件','mep'),
 ('ID-05','定位与开口尺寸','dimensions'),('ID-06','定制立剖与收口','joinery')]

class Scene:
    def __init__(self):self.items=[]
    def rect(self,x,y,w,h,fill='none',stroke='#33483F',sw=12,layer='FURNITURE',id=''):
        self.items.append(dict(kind='rect',x=x,y=y,w=w,h=h,fill=fill,stroke=stroke,sw=sw,layer=layer,id=id))
    def line(self,x1,y1,x2,y2,stroke='#33483F',sw=12,layer='LINE',dash=False):
        self.items.append(dict(kind='line',x1=x1,y1=y1,x2=x2,y2=y2,stroke=stroke,sw=sw,layer=layer,dash=dash))
    def circle(self,x,y,r,fill='none',stroke='#33483F',sw=12,layer='SYMBOL'):
        self.items.append(dict(kind='circle',x=x,y=y,r=r,fill=fill,stroke=stroke,sw=sw,layer=layer))
    def text(self,x,y,text,size=120,color='#273C32',anchor='middle',layer='TEXT'):
        self.items.append(dict(kind='text',x=x,y=y,text=str(text),size=size,color=color,anchor=anchor,layer=layer))
    def dimx(self,x1,x2,y,label=None):
        self.line(x1,y,x2,y,sw=7,layer='DIMENSION')
        for x in [x1,x2]:self.line(x,y-65,x,y+65,sw=7,layer='DIMENSION');self.line(x-35,y-35,x+35,y+35,sw=10,layer='DIMENSION')
        self.text((x1+x2)/2,y+70,label or str(round(x2-x1)),105,layer='DIMENSION')
    def dimy(self,y1,y2,x,label=None):
        self.line(x,y1,x,y2,sw=7,layer='DIMENSION')
        for y in [y1,y2]:self.line(x-65,y,x+65,y,sw=7,layer='DIMENSION')
        self.text(x-50,(y1+y2)/2,label or str(round(y2-y1)),105,anchor='end',layer='DIMENSION')

def wall_parts(w,openings):
    intervals=sorted([(o['start'],o['start']+o['width']) for o in openings if o['wall']==w['id']])
    cursor=w['start'];parts=[]
    for a,b in intervals:
        if a>cursor:parts.append((cursor,a))
        cursor=max(cursor,b)
    if cursor<w['end']:parts.append((cursor,w['end']))
    return parts

def plan(m,kind):
    if kind=='joinery':return joinery(m)
    s=Scene();mats={x['id']:x for x in m['materials']}
    for r in m['rooms']:
        x,y,w,d=r['rect'];fill=mats[r['floor']]['color'] if kind=='finishes' else '#F5F2EA'
        s.rect(x,y,w,d,fill,stroke='#DCD9D1',sw=5,layer='FLOOR',id=r['id'])
        if kind=='finishes':
            step=180 if r['floor']=='M01' else 600
            for n in range(step,int(w),step):s.line(x+n,y,x+n,y+d,'#AA987A' if step==180 else '#A5A39A',3,layer='FINISH_JOINT')
            if step==600:
                for n in range(step,int(d),step):s.line(x,y+n,x+w,y+n,'#A5A39A',3,layer='FINISH_JOINT')
    # Every opening is cut from the same wall object used by the 3D scene.
    walls={w['id']:w for w in m['walls']}
    for w in m['walls']:
        for a,b in wall_parts(w,m['openings']):
            if w['axis']=='x':s.rect(a,w['at'],b-a,w['thickness'],'#394B42','#394B42',5,'WALL')
            else:s.rect(w['at'],a,w['thickness'],b-a,'#394B42','#394B42',5,'WALL')
    for o in m['openings']:
        w=walls[o['wall']];a=o['start'];b=a+o['width'];t=w['thickness'];at=w['at'];color='#4D9296' if o['kind']=='window' else '#97754D'
        if o['kind']=='window':
            for z in [.15,.5,.85]:
                if w['axis']=='x':s.line(a,at+t*z,b,at+t*z,color,9,'WINDOW')
                else:s.line(at+t*z,a,at+t*z,b,color,9,'WINDOW')
        elif o['kind']=='sliding':
            if w['axis']=='x':s.rect(a,at+t*.45,o['width']*.55,20,'none',color,12,'DOOR');s.rect(a+o['width']*.45,at+t*.65,o['width']*.55,20,'none',color,12,'DOOR')
        elif w['axis']=='x':
            s.line(a,at+t,a,at+t+o['width'],color,12,'DOOR')
            pts=[(a+math.cos(k*math.pi/24)*o['width'],at+t+math.sin(k*math.pi/24)*o['width']) for k in range(13)]
            for p,q in zip(pts,pts[1:]):s.line(*p,*q,color,6,'DOOR',True)
        else:
            s.line(at,b,at-o['width'],b,color,12,'DOOR')
            pts=[(at-math.sin(k*math.pi/24)*o['width'],b-math.cos(k*math.pi/24)*o['width']) for k in range(13)]
            for p,q in zip(pts,pts[1:]):s.line(*p,*q,color,6,'DOOR',True)
        if kind=='dimensions':
            if w['axis']=='x':s.text((a+b)/2,at-150 if at>1000 else at+300,o['id']+' '+str(o['width']),95)
            else:s.text(at-350,(a+b)/2,o['id']+' '+str(o['width']),95)
    if kind not in ['dimensions','finishes']:
        for f in sorted(m['furniture'],key=lambda x:x['kind']!='rug'):
            x,y,w,d=f['rect'];fill=mats[f['material']]['color'] if kind=='furniture' else '#ECE9E1'
            if f['kind']=='rug':fill='#DED7C6'
            s.rect(x,y,w,d,fill,'#6D756B',8,'FURNITURE',id=f['id'])
            if f['id']=='F01':
                s.rect(x+80,y+80,w-220,d-160,'none','#8E8B7D',7)
                for n in [1,2]:s.line(x+80,y+d*n/3,x+w-140,y+d*n/3,'#8E8B7D',6)
            if f['id'] in ['F09','F10']:
                s.rect(x+70,y+80,w-140,d-160,'#EEE8DC','#9F9787',5)
                if f['id']=='F09':
                    for py in [y+240,y+d-650]:s.rect(x+120,py,380,450,'#FAF7EF','#B7AA95',5)
                else:s.rect(x+120,y+d-440,w-240,300,'#FAF7EF','#B7AA95',5)
            if f['kind']=='joinery':
                if w>d:
                    for n in range(600,int(w),600):s.line(x+n,y,x+n,y+d,'#8C7455',5)
                else:
                    for n in range(600,int(d),600):s.line(x,y+n,x+w,y+n,'#8C7455',5)
            if kind=='furniture' and f['kind']!='rug':s.text(x+w/2,y+d/2,f['id'],95)
        s.rect(11500,1450,350,550,'none','#6F8180',12,'FIXTURE')
        for x,y in [(10000,370),(10350,370),(10000,600),(10350,600)]:s.circle(x,y,70,stroke='#555F58',sw=12,layer='FIXTURE')
    sx,sy,sw,sd=m['shower']['rect']
    s.rect(sx,sy,sw,sd,'none','#5E9396',12,'FIXTURE')
    s.line(sx,sy,sx+sw,sy,'#5E9396',18,'GLASS')
    s.circle(sx+sw/2,sy+sd/2,110,stroke='#5E9396',layer='FIXTURE')
    if kind=='lighting':
        colors=['#987342','#517866','#777297','#9B5D57']
        for i,g in enumerate(m['control_groups']):
            ls=[l for l in m['lights'] if l['group']==g['id']]
            for a,b in zip(ls,ls[1:]):s.line(*a['xy'],*b['xy'],colors[i%4],9,'LIGHT_CONTROL',True)
        for l in m['lights']:
            x,y=l['xy'];s.circle(x,y,75,'#FAE8A9','#957135',12,'LIGHT')
            s.line(x-100,y,x+100,y,'#957135',7,'LIGHT');s.line(x,y-100,x,y+100,'#957135',7,'LIGHT')
            s.text(x+100,y+130,l['id']+'/'+l['group'],95,anchor='start',layer='LIGHT_LABEL')
    if kind=='mep':
        for e in m['equipment']:
            if 'xy' in e:x,y=e['xy']
            else:
                f=next(f for f in m['furniture'] if f['id']==e['object']);x,y,w,d=f['rect'];x+=w/2;y+=d/2
            s.rect(x-90,y-90,180,180,'#D5E4DC','#507F68',12,'EQUIPMENT')
            s.text(x+120,y+70,e['id'],100,anchor='start',layer='EQUIPMENT_LABEL')
        for p in m['points']:
            x,y=p['xy'];color='#437E95' if '水' in p['type'] or '排' in p['type'] else '#B7674E'
            s.circle(x,y,85,'#FFFDFC',color,15,'SERVICE_POINT')
            # Keep west-wall labels inside the room, clear of the dimension chain.
            label_x=x+140 if x<1000 else x-140
            anchor='start' if x<1000 else 'end'
            s.line(x,y,label_x,y-130,color,6,'SERVICE_LABEL')
            s.text(label_x,y-180,p['id']+' z'+str(p['z_mm']),90,anchor=anchor,layer='SERVICE_LABEL')
    for r in m['rooms']:
        x,y,w,d=r['rect'];label_y=y+260 if r['id'] not in ['R01','R02','R07'] else {'R01':3050,'R02':2970,'R07':3650}[r['id']]
        label_x=x+w/2 if r['id']!='R01' else 5200
        text=r['id']+' '+r['name']
        if kind=='finishes':text+=' '+r['floor']
        s.text(label_x,label_y,text,135)
    s.dimx(0,12000,8700)
    for x1,x2 in [(0,3600),(3720,6800),(6920,9300),(9420,12000)]:s.dimx(x1,x2,8350)
    s.dimy(0,8000,-750)
    s.dimy(0,3320,-350);s.dimy(3320,4320,-350);s.dimy(4440,8000,-350)
    s.line(12400,7100,12400,7800,sw=25,layer='NORTH');s.line(12400,7800,12280,7570,sw=20,layer='NORTH');s.line(12400,7800,12520,7570,sw=20,layer='NORTH');s.text(12400,8000,'N',180)
    return s

def joinery(m):
    s=Scene()
    s.text(2000,8100,'J01 主卧衣柜立面与内部条件',180)
    x,y=700,5000;w,h=2400,2400
    s.rect(x,y,w,h,'#D8C3A4','#48574B',15,'JOINERY')
    s.rect(x+20,y+100,w-40,h-120,'#F0E8DB','#79664F',10,'JOINERY')
    bay=(w-40-4*18)/3
    for n in [1,2]:s.rect(x+20+18+n*bay+(n-1)*18,y+100,18,h-120,'#A6865E','#79664F',6,'JOINERY')
    for n in range(3):
        xx=x+38+n*(bay+18)
        s.text(xx+bay/2,y+2100,f'净宽 {bay:.1f}',105)
        if n==0:s.line(xx,y+1800,xx+bay,y+1800,sw=16);s.text(xx+bay/2,y+1000,'挂衣',130)
        elif n==1:
            for z in [500,900,1300,1700]:s.line(xx,y+z,xx+bay,y+z,sw=12)
        else:
            for z in [350,600,850]:s.rect(xx,y+z,bay,220,'none','#79664F',8,'JOINERY')
            s.text(xx+bay/2,y+1450,'抽屉 / 叠放',120)
    s.dimx(x,x+w,y-250);s.dimy(y,y+h,x-250)
    s.text(2000,4500,'外包2400×600×2400；板18，背9，踢脚100，收口20',115)
    s.text(6000,8100,'J07 厨房南侧立面意向',180)
    x,y=4400,5000
    s.rect(x,y,2480,850,'#C7A77B','#48574B',15,'JOINERY')
    s.rect(x,y+830,2480,20,'#D8D4C9','#48574B',10,'JOINERY')
    for n in [600,1200,1800]:s.line(x+n,y+100,x+n,y+830,sw=10)
    s.rect(x,y,2480,100,'#A98960','#48574B',8,'JOINERY')
    s.rect(x,y+850,2480,600,'#D3CEC2','#9B9A8D',8,'FINISH')
    s.dimx(x,x+2480,y-250);s.dimy(y,y+850,x-250)
    s.text(5650,4500,'柜身730+踢脚100+台面20；设备开孔待选型',115)
    s.text(9600,8100,'J01 剖面',180)
    s.rect(9200,5000,600,2400,'#D8C3A4','#48574B',15,'JOINERY')
    s.rect(9209,5100,573,2282,'#F7F0E4','#79664F',8,'JOINERY')
    s.dimx(9200,9800,4750);s.text(9500,4500,'深600 / 背9 / 门18',115)
    s.text(2000,3300,'N01 干湿地面平接意向',180)
    s.rect(600,2050,2400,150,'#C7A77B','#48574B',10,'DETAIL')
    s.rect(600,2000,2400,50,'#DDD7CC','#48574B',10,'DETAIL')
    s.rect(3000,2100,2400,100,'#C8C5BC','#48574B',10,'DETAIL')
    s.rect(3000,2000,2400,100,'#D9D5CE','#48574B',10,'DETAIL')
    s.line(3000,1980,3000,2270,'#6B7770',25,'DETAIL')
    s.text(1700,2450,'M01 地板15+基层5',120);s.text(4200,2450,'M02 地砖10+粘结10',120)
    s.text(3000,1700,'仅表达材料与完成面关系；实际基层高差现场复核',120)
    s.text(8500,3100,'N02 / N03 深化条件',180)
    for i,line in enumerate(['湿区防水、坡度与排水系统联合深化','柜墙收口20；柜门与设备检修互不遮挡','玻璃隔断1400×2100；五金按样板确认','未取得设备安装图前不下生产订单']):s.text(6900,2700-i*330,line,125,anchor='start')
    return s

def svg(s,path,title):
    view=(-1200,-1000,14600,10500);v=[]
    for p in s.items:
        if p['kind']=='rect':v.append(f'<rect x="{p["x"]}" y="{-p["y"]-p["h"]}" width="{p["w"]}" height="{p["h"]}" fill="{p["fill"]}" stroke="{p["stroke"]}" stroke-width="{p["sw"]}"/>')
        elif p['kind']=='line':v.append(f'<line x1="{p["x1"]}" y1="{-p["y1"]}" x2="{p["x2"]}" y2="{-p["y2"]}" stroke="{p["stroke"]}" stroke-width="{p["sw"]}"'+(' stroke-dasharray="70 45"' if p.get('dash') else '')+'/>')
        elif p['kind']=='circle':v.append(f'<circle cx="{p["x"]}" cy="{-p["y"]}" r="{p["r"]}" fill="{p["fill"]}" stroke="{p["stroke"]}" stroke-width="{p["sw"]}"/>')
        else:v.append(f'<text x="{p["x"]}" y="{-p["y"]}" font-family="PingFang SC,Microsoft YaHei,sans-serif" font-size="{p["size"]}" text-anchor="{p["anchor"]}" fill="{p["color"]}">{html.escape(p["text"])}</text>')
    Path(path).write_text(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="-1200 -9400 14600 10500"><title>{html.escape(title)}</title><rect x="-1200" y="-9400" width="14600" height="10500" fill="#FFFEFA"/>'+''.join(v)+'</svg>')

def dxf_document(m):
    import ezdxf
    from ezdxf.enums import TextEntityAlignment
    doc=ezdxf.new('R2018');doc.units=ezdxf.units.MM
    doc.header['$INSUNITS']=4
    doc.styles.new('CJK',dxfattribs={'font':'Arial Unicode.ttf'})
    ms=doc.modelspace()
    for index,(code,title,kind) in enumerate(SHEETS):
        ox=(index%3)*17000;oy=-(index//3)*12500;s=plan(m,kind)
        for p in s.items:
            layer=code+'_'+p['layer']
            if layer not in doc.layers:
                color=1 if 'SERVICE' in layer else 3 if 'LIGHT' in layer else 7
                doc.layers.new(layer,dxfattribs={'color':color})
            a={'layer':layer}
            if p['kind']=='rect':
                x,y,w,h=p['x']+ox,p['y']+oy,p['w'],p['h'];ms.add_lwpolyline([(x,y),(x+w,y),(x+w,y+h),(x,y+h)],close=True,dxfattribs=a)
            elif p['kind']=='line':ms.add_line((p['x1']+ox,p['y1']+oy),(p['x2']+ox,p['y2']+oy),dxfattribs=a)
            elif p['kind']=='circle':ms.add_circle((p['x']+ox,p['y']+oy),p['r'],dxfattribs=a)
            else:
                align={'middle':TextEntityAlignment.BOTTOM_CENTER,'start':TextEntityAlignment.BOTTOM_LEFT,'end':TextEntityAlignment.BOTTOM_RIGHT}[p['anchor']]
                ms.add_text(p['text'],dxfattribs={**a,'height':p['size'],'style':'CJK'}).set_placement((p['x']+ox,p['y']+oy),align=align)
        ms.add_text(code+' '+title+' / '+m['revision']+' / mm / DEMO',dxfattribs={'height':200,'style':'CJK'}).set_placement((ox,oy+9400))
    return doc

def pdf_scene(canvas,s,x,y,scale,font='STSong-Light'):
    from reportlab.lib.colors import HexColor
    canvas.saveState();canvas.translate(x,y);canvas.scale(scale,scale)
    for p in s.items:
        if p['kind']=='text':
            canvas.setFillColor(HexColor(p['color']));canvas.setFont(font,p['size'])
            method={'middle':canvas.drawCentredString,'start':canvas.drawString,'end':canvas.drawRightString}[p['anchor']]
            method(p['x'],p['y'],p['text']);continue
        canvas.setStrokeColor(HexColor(p['stroke']));canvas.setLineWidth(p['sw'])
        if p.get('fill','none')!='none':canvas.setFillColor(HexColor(p['fill']))
        canvas.setDash([70,45] if p.get('dash') else [])
        if p['kind']=='rect':canvas.rect(p['x'],p['y'],p['w'],p['h'],fill=int(p['fill']!='none'),stroke=1)
        elif p['kind']=='circle':canvas.circle(p['x'],p['y'],p['r'],fill=int(p['fill']!='none'),stroke=1)
        else:canvas.line(p['x1'],p['y1'],p['x2'],p['y2'])
    canvas.restoreState()
